// include sass
import "./sass/style.sass";
import "./img/favicon/favicon.ico";



//if (module.hot) {
//  module.hot.accept('./lib/tabs.js', function() {
//     console.log('Accepting the updated printMe module!');
//      openCity();
//   })
// }

